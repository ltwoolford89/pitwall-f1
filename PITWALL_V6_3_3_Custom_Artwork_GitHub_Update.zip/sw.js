/* PITWALL V6: Offline app shell. Live API calls remain network-owned; app saves verified data in local storage. */
const STATIC_CACHE='pitwall-static-v6_3_3-custom-2026-10-10';
const SHELL=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./logo.svg','./v2.js','./v3.js','./v3.css','./v4.js','./v4.css','./v4_1.js','./v4_1_profiles.js?v=6.3.3','./v4_1.css','./v4_2.js','./v4_2.css','./v4_3.js','./v4_3.css','./v4_4.js?v=6.3.3','./v4_4.css','./v5.js','./v5.css','./v5_1.js','./v5_1.css','./v5_2.js','./v5_2.css','./v5_3.js?v=5.4','./v5_3.css?v=5.4','./v5_4.js?v=5.4','./v5_4.css?v=5.4','./v6.css?v=6.3.3','./v6_pixels.js?v=6.3.3','./v6.js?v=6.3.3','./portraits/face/ANT.png','./portraits/helmet/ANT.png','./portraits/face/RUS.png','./portraits/helmet/RUS.png','./portraits/face/HAM.png','./portraits/helmet/HAM.png','./portraits/face/LEC.png','./portraits/helmet/LEC.png','./portraits/face/NOR.png','./portraits/helmet/NOR.png','./portraits/face/VER.png','./portraits/helmet/VER.png','./portraits/face/PIA.png','./portraits/helmet/PIA.png','./portraits/face/HAD.png','./portraits/helmet/HAD.png','./portraits/face/LAW.png','./portraits/helmet/LAW.png','./portraits/face/GAS.png','./portraits/helmet/GAS.png','./portraits/face/BEA.png','./portraits/helmet/BEA.png','./portraits/face/COL.png','./portraits/helmet/COL.png','./portraits/face/LIN.png','./portraits/helmet/LIN.png','./portraits/face/BOR.png','./portraits/helmet/BOR.png','./portraits/face/HUL.png','./portraits/helmet/HUL.png','./portraits/face/OCO.png','./portraits/helmet/OCO.png','./portraits/face/ALO.png','./portraits/helmet/ALO.png','./portraits/face/SAI.png','./portraits/helmet/SAI.png','./portraits/face/ALB.png','./portraits/helmet/ALB.png','./portraits/face/TSU.png','./portraits/helmet/TSU.png','./portraits/face/STR.png','./portraits/helmet/STR.png','./portraits/face/BOT.png','./portraits/helmet/BOT.png','./portraits/face/PER.png','./portraits/helmet/PER.png','./custom_uploads/fullbody/VER.png','./custom_uploads/fullbody/HAM.png','./custom_uploads/fullbody/ANT.png','./custom_uploads/fullbody/RUS.png','./custom_uploads/fullbody/LEC.png','./custom_uploads/mercedes_logo.png','./custom_uploads/ferrari_logo.png','./custom_uploads/redbull_logo.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(STATIC_CACHE).then(cache=>cache.addAll(SHELL)));self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('pitwall-')&&k!==STATIC_CACHE).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',event=>{
 const request=event.request;
 if(request.method!=='GET')return;
 const u=new URL(request.url);
 if(u.origin!==self.location.origin)return;
 if(request.mode==='navigate'){
  event.respondWith(fetch(request).then(resp=>{if(resp.ok){const copy=resp.clone();caches.open(STATIC_CACHE).then(c=>c.put('./index.html',copy));}return resp;}).catch(async()=>await caches.match('./index.html')||Response.error()));
  return;
 }
 event.respondWith(caches.match(request).then(async cached=>cached||fetch(request).then(response=>{if(response.ok)caches.open(STATIC_CACHE).then(c=>c.put(request,response.clone()));return response;})));
});
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
