# PITWALL V6.3.3 — Custom Artwork & Profile Test

This is a complete iPhone-first PITWALL web-app test build using the art you provided. This package is ready for installation; it is not yet live.

## Changes
- Full-body profile artwork opacity reduced to 35% and scaled to 92% of the profile header height, aligned inside the right border.
- Same 512 x 560 portrait canvas for every driver and both face/helmet variants.
- All driver art positioned against the bottom of its portrait frame.
- Max Verstappen and George Russell helmet images have their black image backgrounds made transparent.
- Your full-body helmet illustrations appear as faded large backgrounds inside Max, Lewis, Kimi, George and Charles's driver profile headers.
- Your Ferrari, Mercedes and Red Bull logos remain integrated. Other teams use original fan badges.
- The existing full standings, Calendar, career, widgets-like in-app cards, and scrolling logic are retained.

## Deploy test version via GitHub Pages
1. Back up career data in PITWALL settings first.
2. Download the ZIP, extract it, and upload the CONTENTS of this folder to the root of your GitHub Pages repository, replacing existing files.
3. IMPORTANT: Preserve subfolders `portraits`, `custom_uploads`, and `custom_uploads/fullbody`.
4. Let GitHub Pages deploy. Open the site in Safari, refresh, then reopen the Home Screen app.
5. Face/helmet toggle is in Settings; open a driver profile to test the full-body background.

Old data and local saves are not intentionally deleted. However, a backup is strongly recommended before any update.
